from rest_framework.decorators import api_view
from rest_framework.response import Response
from rest_framework import status
from .models import Order

@api_view(['POST'])
def create_order(request):
    name = request.data.get('name')
    item = request.data.get('item')
    quantity = request.data.get('quantity')

    if not name or not item or not quantity:
        return Response(
            {"message": "All fields are required"},
            status=status.HTTP_400_BAD_REQUEST
        )

    Order.objects.create(
        name=name,
        item=item,
        quantity=quantity
    )

    return Response(
        {"message": "Order placed successfully!"},
        status=status.HTTP_201_CREATED
    )
