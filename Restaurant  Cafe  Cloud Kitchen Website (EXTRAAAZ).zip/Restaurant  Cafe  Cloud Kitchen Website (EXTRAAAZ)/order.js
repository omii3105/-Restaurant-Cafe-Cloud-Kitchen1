document.getElementById("orderForm").addEventListener("submit", function (e) {
  e.preventDefault();

  const name = document.getElementById("name").value;
  const item = document.getElementById("item").value;
  const quantity = document.getElementById("quantity").value;

  fetch("http://127.0.0.1:8000/api/order/", {
    method: "POST",
    headers: {
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      name: name,
      item: item,
      quantity: quantity
    })
  })
  .then(response => response.json())
  .then(data => {
    alert(data.message);
    document.getElementById("orderForm").reset();
  })
  .catch(error => {
    alert("Error placing order");
    console.error(error);
  });
});
